# Graph model

## Definitions
The sequence graph is made up of nodes and directed edges. Each node holds a (non-empty) sequence. Edges connect
nodes and do not hold sequences themselves. A path is a sequence of nodes, where each node is connected to its successor with a directed edge. A path defines a sequence in the graph.

## Graph class
### Files
- include/graphcore/Graph.hh
- tests
    - GraphOperationsTest.cpp
    - GraphCoordinatesTest.cpp

The graph class holds nodes, edges and edge labels (used for path families).
Nodes are simple structs with a name and sequence. Within a graph each node has a unique NodeID, numbered from 0 to
graph.numNodes.
Edges are defined as pairs of NodeIDs and are stored directly within the graph using a node adjacency list.
Every edge can optionally be labeled with one or more labels.

Graphs are allowed to contain self-loops (edges from a node to itself). Excluding self-loop edges the graph has to be a DAG. A path
may pass through such an loop-edge multiple times, defining a repeated sequence.

## Paths
See [path](paths.md) and [path family](path_families.md) documentation.

## JSON model
Graphs can be serialized in JSON. The format is
- "nodes": array of node objects containing
    - "name": string (required) - Unique name for this node
    - "sequence": string - Nucleotide sequence of this node
        - [Extended alphabet](query_and_reference_sequences.md)
        - Either "sequence" or "reference" is required
    - "reference": string - Region in the reference genome
        - Can be used to define the sequence of a (reference) node instead of "sequence"
- "edges": array of edge objects containing
    - "from": string - name of the start node
    - "to": string - name of the end node
    - "labels": array of string - edge labels applied to this edge
- "paths": array of path objects (optional) containing
    - path_id: string - name of the path
    - nodes: array of string - name of nodes in the path (in order)
- "model_name": string (optional) - name for the graph
- "target_regions": array of string (optional) - regions in the reference genome to find reads to align to the graph

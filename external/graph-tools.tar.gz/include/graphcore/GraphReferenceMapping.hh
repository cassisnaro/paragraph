// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2017 Illumina, Inc.
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:

// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.

// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#pragma once

#include <memory>

#include "Graph.hh"
#include "Path.hh"

#include <set>

namespace graphtools
{

class GraphReferenceMapping
{
public:
    explicit GraphReferenceMapping(Graph const* graph);
    GraphReferenceMapping(GraphReferenceMapping const&) = delete;
    GraphReferenceMapping(GraphReferenceMapping&&) noexcept;
    GraphReferenceMapping& operator=(GraphReferenceMapping const&) = delete;
    GraphReferenceMapping& operator=(GraphReferenceMapping&&) noexcept;
    virtual ~GraphReferenceMapping();

    void addMapping(Path const& path, std::string const& contig, int32_t start);

    struct ReferencePosition
    {
        std::string contig;
        int32_t pos;

        friend bool operator<(ReferencePosition const& lhs, ReferencePosition const& rhs)
        {
            return lhs.contig < rhs.contig || (lhs.contig == rhs.contig && lhs.pos < rhs.pos);
        }
        friend bool operator==(ReferencePosition const& lhs, ReferencePosition const& rhs)
        {
            return lhs.contig == rhs.contig && lhs.pos == rhs.pos;
        }
        friend std::ostream& operator<<(std::ostream& output, ReferencePosition const& ri)
        {
            output << ri.contig << ":" << ri.pos;
            return output;
        }
    };

    struct ReferenceInterval
    {
        std::string contig;
        int32_t start;
        int32_t end;

        friend bool operator<(ReferenceInterval const& lhs, ReferenceInterval const& rhs)
        {
            return lhs.contig < rhs.contig || (lhs.contig == rhs.contig && lhs.start < rhs.start)
                || (lhs.contig == rhs.contig && lhs.start == rhs.start && lhs.end < rhs.end);
        }
        friend bool operator==(ReferenceInterval const& lhs, ReferenceInterval const& rhs)
        {
            return lhs.contig == rhs.contig && lhs.start == rhs.start && lhs.end == rhs.end;
        }
        friend std::ostream& operator<<(std::ostream& output, ReferenceInterval const& ri)
        {
            output << ri.contig << ":" << ri.start << "-" << ri.end;
            return output;
        }
    };

    typedef std::set<ReferencePosition> ReferencePositions;
    typedef std::set<std::pair<Path, ReferenceInterval>> ReferenceIntervals;
    /**
     * Get all positions that a node + offset maps to
     */
    ReferencePositions map(NodeId node, int32_t offset) const;

    /**
     * Decompose a path into reference paths with matched reference intervals
     */
    ReferenceIntervals map(Path const& path) const;

private:
    struct Impl;
    std::unique_ptr<Impl> pimpl_;
};
}

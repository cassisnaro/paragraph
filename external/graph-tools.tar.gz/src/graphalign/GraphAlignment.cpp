// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2018 Illumina, Inc.
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:

// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.

// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include <sstream>
#include <stdexcept>
#include <typeindex>

#include "graphalign/GraphAlignment.hh"

using std::list;
using std::map;
using std::string;
using std::to_string;

namespace graphtools
{
void GraphAlignment::assertValidity() const
{
    const int32_t alignment_reference_start = alignments_.front().referenceStart();

    const Alignment& last_alignment = alignments_.back();
    const int32_t alignment_reference_end = last_alignment.referenceLength() + last_alignment.referenceStart() - 1;

    if (alignment_reference_start != path_.startPosition() || alignment_reference_end != path_.endPosition())
    {
        std::ostringstream graph_alignment_encoding;
        graph_alignment_encoding << *this;
        throw std::logic_error(
            "Path " + path_.encode() + " is not compatible with graph alignment " + graph_alignment_encoding.str());
    }
}

uint32_t GraphAlignment::queryLength() const
{
    uint32_t query_span = 0;
    for (const auto& alignment : alignments_)
    {
        query_span += alignment.queryLength();
    }
    return query_span;
}

uint32_t GraphAlignment::referenceLength() const
{
    uint32_t reference_span = 0;
    for (const auto& alignment : alignments_)
    {
        reference_span += alignment.referenceLength();
    }
    return reference_span;
}

uint32_t GraphAlignment::numMatches() const
{
    uint32_t num_matches = 0;
    for (const auto& alignment : alignments_)
    {
        num_matches += alignment.numMatched();
    }
    return num_matches;
}

bool GraphAlignment::overlapsNode(NodeId node_id) const
{
    return path_.checkOverlapWithNode(static_cast<NodeId>(node_id));
}

list<int32_t> GraphAlignment::getIndexesOfNode(NodeId node_id) const
{
    list<int32_t> indexes;
    const auto num_alignments = static_cast<int32_t>(alignments_.size());
    for (int32_t node_index = 0; node_index != num_alignments; ++node_index)
    {
        const NodeId cur_node_id = path_.getNodeIdByIndex(static_cast<size_t>(node_index));
        if (cur_node_id == node_id)
        {
            indexes.push_back(node_index);
        }
    }
    return indexes;
}

string GraphAlignment::generateCigar() const
{
    string graph_cigar;
    for (int32_t index = 0; index != (int32_t)size(); ++index)
    {
        const int32_t node_id = path_.getNodeIdByIndex(static_cast<size_t>(index));
        graph_cigar += std::to_string(node_id);
        const Alignment& alignment = alignments_[index];
        graph_cigar += "[" + alignment.generateCigar() + "]";
    }
    return graph_cigar;
}

bool GraphAlignment::operator<(const GraphAlignment& other) const
{
    if (!(path_ == other.path_))
    {
        return path_ < other.path_;
    }

    return alignments_ < other.alignments_;
}

std::ostream& operator<<(std::ostream& out, const GraphAlignment& graph_alignment)
{
    for (int32_t node_index = 0; node_index != (int32_t)graph_alignment.size(); ++node_index)
    {
        const int32_t node_id = graph_alignment.getNodeIdByIndex(node_index);
        out << node_id << "[" << graph_alignment[node_index] << "]";
    }
    return out;
}
}

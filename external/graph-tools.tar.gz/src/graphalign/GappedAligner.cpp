// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2018 Illumina, Inc.
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:

// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.

// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "graphalign/GappedAligner.hh"

#include "graphalign/GraphAlignmentOperations.hh"
#include "graphalign/LinearAlignmentOperations.hh"
#include "graphalign/PinnedAligner.hh"
#include "graphcore/PathOperations.hh"

using std::list;
using std::make_pair;
using std::pair;
using std::string;
using std::to_string;
using std::vector;

namespace graphtools
{

list<GraphAlignment> GappedGraphAligner::align(const string& query) const
{
    const list<string> kmers = extractKmersFromAllPositions(query, kmer_len_);

    size_t kmer_start_on_query = 0;
    for (const string& kmer : kmers)
    {
        // Initiate alignment from a unique kmer.
        if (kmer_index_.numPaths(kmer) == 1)
        {
            const Path kmer_path = kmer_index_.getPaths(kmer).front();
            return extendKmerMatchToFullAlignments(kmer_path, query, kmer_start_on_query);
        }
        ++kmer_start_on_query;
    }

    return {};
}

list<GraphAlignment> GappedGraphAligner::extendKmerMatchToFullAlignments(
    const Path& kmer_path, const string& query, size_t kmer_start_on_query) const
{
    const size_t query_prefix_len = kmer_start_on_query;
    const size_t query_suffix_len = query.length() - kmer_len_ - query_prefix_len;

    // const string query_kmer = query.substr(query_prefix_len, kmer_len_);
    Alignment kmer_alignment(0, to_string(kmer_len_) + "M");

    const string query_prefix = query.substr(0, query_prefix_len);
    list<PathAndAlignment> prefix_extensions;
    if (query_prefix_len != 0)
    {
        prefix_extensions = extendAlignmentPrefix(kmer_path, query_prefix, query_prefix_len + padding_len_);
    }

    for (PathAndAlignment& path_and_alignment : prefix_extensions)
    {
        Alignment& alignment = path_and_alignment.second;
        kmer_alignment.setReferenceStart(alignment.referenceLength());
        alignment = mergeAlignments(alignment, kmer_alignment);
    }

    if (prefix_extensions.empty())
    {
        if (query_prefix_len != 0)
        {
            Alignment softclip_alignment(0, to_string(query_prefix_len) + "S");
            kmer_alignment = mergeAlignments(softclip_alignment, kmer_alignment);
        }
        prefix_extensions.push_back(make_pair(kmer_path, kmer_alignment));
    }

    list<PathAndAlignment> full_extensions;
    if (query_suffix_len != 0)
    {
        const string query_suffix = query.substr(query_prefix_len + kmer_len_, query_suffix_len);
        for (PathAndAlignment& path_and_alignment : prefix_extensions)
        {
            Path& path = path_and_alignment.first;
            Alignment& prefix_alignment = path_and_alignment.second;

            list<PathAndAlignment> extensions
                = extendAlignmentSuffix(path, query_suffix, query_suffix_len + padding_len_);

            for (PathAndAlignment& extended_path_and_alignment : extensions)
            {
                Alignment& suffix_alignment = extended_path_and_alignment.second;
                suffix_alignment.setReferenceStart(path.length());
                suffix_alignment = mergeAlignments(prefix_alignment, suffix_alignment);
            }

            full_extensions.splice(full_extensions.end(), extensions);
        }
    }

    if (query_suffix_len == 0)
    {
        full_extensions = prefix_extensions;
    }
    else if (full_extensions.empty())
    {
        for (PathAndAlignment& path_and_alignment : prefix_extensions)
        {
            Path& path = path_and_alignment.first;
            Alignment& prefix_alignment = path_and_alignment.second;

            Alignment softclip_alignment(path.length(), to_string(query_suffix_len) + "S");
            prefix_alignment = mergeAlignments(prefix_alignment, softclip_alignment);
        }
        full_extensions = prefix_extensions;
    }

    list<GraphAlignment> graph_alignments;
    for (PathAndAlignment& path_and_alignment : full_extensions)
    {
        Path& path = path_and_alignment.first;
        Alignment& alignment = path_and_alignment.second;
        graph_alignments.push_back(projectAlignmentOntoGraph(alignment, path));
    }

    graph_alignments.sort();
    graph_alignments.unique();
    return graph_alignments;
}

list<PathAndAlignment>
GappedGraphAligner::extendAlignmentPrefix(const Path& seed_path, const string& query_piece, size_t extension_len) const
{
    const size_t initial_seed_path_length = seed_path.length();
    PinnedAligner pinned_aligner(match_score_, mismatch_score_, gap_score_);
    list<PathAndAlignment> top_paths_and_alignments;
    int32_t top_alignment_score = INT32_MIN;

    const list<Path> path_extensions = extendPathStart(seed_path, extension_len);
    for (const auto& path : path_extensions)
    {
        const string path_seq_piece = path.seq().substr(0, extension_len);

        Alignment alignment = pinned_aligner.suffixAlign(path_seq_piece, query_piece);
        const int32_t alignment_score = scoreAlignment(alignment, match_score_, mismatch_score_, gap_score_);

        if (top_alignment_score < alignment_score)
        {
            top_paths_and_alignments.clear();
            top_alignment_score = alignment_score;
        }

        if (top_alignment_score == alignment_score)
        {
            top_paths_and_alignments.push_back(make_pair(path, alignment));
        }
    }

    for (PathAndAlignment& path_and_alignment : top_paths_and_alignments)
    {
        Path& path = path_and_alignment.first;
        Alignment& alignment = path_and_alignment.second;
        alignment.setReferenceStart(0);

        const int32_t overhang = path.length() - initial_seed_path_length - alignment.referenceLength();
        path.shrinkStartBy(overhang);
    }

    return top_paths_and_alignments;
}

list<PathAndAlignment>
GappedGraphAligner::extendAlignmentSuffix(const Path& seed_path, const string& query_piece, size_t extension_len) const
{
    const size_t initial_seed_path_length = seed_path.length();
    PinnedAligner pinned_aligner(match_score_, mismatch_score_, gap_score_);
    list<PathAndAlignment> top_paths_and_alignments;
    int32_t top_alignment_score = INT32_MIN;

    const list<Path> path_extensions = extendPathEnd(seed_path, extension_len);
    for (const auto& path : path_extensions)
    {
        const string path_seq_piece = path.seq().substr(seed_path.length());
        Alignment alignment = pinned_aligner.prefixAlign(path_seq_piece, query_piece);
        const int32_t alignment_score = scoreAlignment(alignment, match_score_, mismatch_score_, gap_score_);

        if (top_alignment_score < alignment_score)
        {
            top_paths_and_alignments.clear();
            top_alignment_score = alignment_score;
        }

        if (top_alignment_score == alignment_score)
        {
            top_paths_and_alignments.push_back(std::make_pair(path, alignment));
        }
    }

    for (PathAndAlignment& path_and_alignment : top_paths_and_alignments)
    {
        Path& path = path_and_alignment.first;
        Alignment& alignment = path_and_alignment.second;

        const int32_t overhang = path.length() - initial_seed_path_length - alignment.referenceLength();
        path.shrinkEndBy(overhang);
    }

    return top_paths_and_alignments;
}
}

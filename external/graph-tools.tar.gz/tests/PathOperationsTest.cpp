// -*- mode: c++; indent-tabs-mode: nil; -*-
//
// Copyright (c) 2018 Illumina, Inc.
// All rights reserved.

// Redistribution and use in source and binary forms, with or without
// modification, are permitted provided that the following conditions are met:

// 1. Redistributions of source code must retain the above copyright notice, this
//    list of conditions and the following disclaimer.

// 2. Redistributions in binary form must reproduce the above copyright notice,
//    this list of conditions and the following disclaimer in the documentation
//    and/or other materials provided with the distribution.

// THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
// ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
// WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
// DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT HOLDER OR CONTRIBUTORS BE LIABLE
// FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
// DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
// SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
// CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
// OR TORT INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
// OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

#include "graphcore/PathOperations.hh"

#include "gtest/gtest.h"

#include <list>
#include <string>
#include <vector>

#include "graphcore/Graph.hh"
#include "graphcore/GraphBuilders.hh"
#include "graphcore/Path.hh"

using std::list;
using std::string;
using std::vector;

using namespace graphtools;

// enable debug outputs
// #define DEBUG_PATHOPERATIONS_TEST

TEST(ExtendingPathStarts, TypicalPath_StartExtended)
{
    Graph graph = makeDeletionGraph("AAACC", "TTGGG", "TTAAA");
    Path path(&graph, 4, { 0 }, 4);
    list<Path> extended_paths = extendPathStart(path, 1);

    list<Path> expected_paths = { Path(&graph, 3, { 0 }, 4) };

    ASSERT_EQ(expected_paths, extended_paths);
}

TEST(ExtendingPathsByGivenLength, TypicalPathInStrGraph_PathExtended)
{
    Graph graph = makeStrGraph("TTT", "AT", "CCCCC");

    {
        Path path(&graph, 1, { 0 }, 1);
        const int32_t start_extension_len = 0;
        const int32_t end_extension_len = 6;
        const list<Path> path_extensions = extendPath(path, start_extension_len, end_extension_len);

        const list<Path> expected_path_extensions
            = { Path(&graph, 1, { 0, 1, 1, 1 }, 0), Path(&graph, 1, { 0, 1, 1, 2 }, 0), Path(&graph, 1, { 0, 1, 2 }, 2),
                Path(&graph, 1, { 0, 2 }, 4) };
        ASSERT_EQ(expected_path_extensions, path_extensions);
    }

    {
        Path path(&graph, 0, { 1 }, 1);
        const int32_t start_extension = 1;
        const int32_t end_extension = 1;
        const list<Path> path_extensions = extendPath(path, start_extension, end_extension);

        const list<Path> expected_path_extensions = {
            Path(&graph, 2, { 0, 1, 1 }, 0),
            Path(&graph, 2, { 0, 1, 2 }, 0),
            Path(&graph, 1, { 1, 1, 1 }, 0),
            Path(&graph, 1, { 1, 1, 2 }, 0),
        };
        ASSERT_EQ(expected_path_extensions, path_extensions);
    }
}

TEST(ExtendingPathsByGivenLength, TypicalPathInHomopolymerGraph_PathExtended)
{
    Graph graph = makeStrGraph("T", "A", "C");

    Path path(&graph, 0, { 1 }, 0);
    const int32_t start_extension = 3;
    const int32_t end_extension = 3;
    const list<Path> path_extensions = extendPath(path, start_extension, end_extension);

    const list<Path> expected_path_extensions
        = { Path(&graph, 0, { 0, 1, 1, 1, 1, 1, 1 }, 0), Path(&graph, 0, { 0, 1, 1, 1, 1, 1, 2 }, 0),
            Path(&graph, 0, { 1, 1, 1, 1, 1, 1, 1 }, 0), Path(&graph, 0, { 1, 1, 1, 1, 1, 1, 2 }, 0) };
    ASSERT_EQ(expected_path_extensions, path_extensions);
}

TEST(ExtendingPathsMatching, TypicalPath_ExtendedWithinNode)
{
    Graph graph = makeDeletionGraph("AAACC", "TTGGG", "TTAAA");

    const Path path(&graph, 2, { 1 }, 2);
    const string query = "TTGGG";
    {
        size_t qpos = 2;
        const Path start_extended = extendPathStartMatching(path, query, qpos);
        const Path expected_path(&graph, 0, { 1 }, 2);
        ASSERT_EQ(expected_path, start_extended);
        ASSERT_EQ(qpos, 0ull);
    }
    {
        const size_t qpos = 2;
        const Path end_extended = extendPathEndMatching(path, query, qpos);
        const Path expected_path(&graph, 2, { 1 }, 4);
        ASSERT_EQ(expected_path, end_extended);
    }
    {
        size_t qpos = 2;
        const Path both_extended = extendPathMatching(path, query, qpos);
        const Path expected_path(&graph, 0, { 1 }, 4);
        ASSERT_EQ(expected_path, both_extended);
        ASSERT_EQ(qpos, 0ull);
    }
}

TEST(ExtendingPathsMatching, TypicalPath_ExtendedAcrossNodes)
{
    Graph graph = makeDeletionGraph("AAACC", "TTGGG", "TTAAA");

    const Path path(&graph, 2, { 1 }, 2);
    const string query = "CTTGGGT";
    {
        size_t qpos = 3;
        const Path start_extended = extendPathStartMatching(path, query, qpos);
        const Path expected_path(&graph, 4, { 0, 1 }, 2);
        ASSERT_EQ(expected_path, start_extended);
        ASSERT_EQ(qpos, 0ull);
    }
    {
        const size_t qpos = 3;
        const Path end_extended = extendPathEndMatching(path, query, qpos);
        const Path expected_path(&graph, 2, { 1, 2 }, 0);
        ASSERT_EQ(expected_path, end_extended);
    }
    {
        size_t qpos = 3;
        const Path both_extended = extendPathMatching(path, query, qpos);
        const Path expected_path(&graph, 4, { 0, 1, 2 }, 0);
        ASSERT_EQ(expected_path, both_extended);
        ASSERT_EQ(qpos, 0ull);
    }
}

TEST(ExtendingPathsMatching, TypicalPath_ExtendedWhenUniqMatch)
{
    {
        Graph graph = makeDeletionGraph("AAACC", "TTGGG", "TTAAA");
        const Path path(&graph, 4, { 0 }, 4);
        {
            const string query = "CTTGG";
            size_t qpos = 0;
            const Path extended = extendPathMatching(path, query, qpos);
            const Path expected_path(&graph, 4, { 0, 1 }, 3);
            ASSERT_EQ(expected_path, extended);
            ASSERT_EQ(qpos, 0ull);
        }
        {
            const string query = "CTTAA";
            size_t qpos = 0;
            const Path extended = extendPathMatching(path, query, qpos);
            const Path expected_path(&graph, 4, { 0, 2 }, 3);
            ASSERT_EQ(expected_path, extended);
            ASSERT_EQ(qpos, 0ull);
        }
    }
    {
        Graph graph = makeDeletionGraph("AAACC", "ATGCC", "TTAAA");
        const Path path(&graph, 0, { 2 }, 0);
        {
            const string query = "TGCCT";
            size_t qpos = 4;
            const Path extended = extendPathMatching(path, query, qpos);
            const Path expected_path(&graph, 1, { 1, 2 }, 0);
            ASSERT_EQ(expected_path, extended);
            ASSERT_EQ(qpos, 0ull);
        }
        {
            const string query = "AACCT";
            size_t qpos = 4;
            const Path extended = extendPathMatching(path, query, qpos);
            const Path expected_path(&graph, 1, { 0, 2 }, 0);
            ASSERT_EQ(expected_path, extended);
            ASSERT_EQ(qpos, 0ull);
        }
    }
}

TEST(ExtendingPathsMatching, TypicalPath_NotExtendedWhenNonUniqMatch)
{
    {
        Graph graph = makeDeletionGraph("AAACC", "TTGGG", "TTAAA");
        const Path path(&graph, 4, { 0 }, 4);
        const string query = "CTT";
        size_t qpos = 0;
        const Path extended = extendPathMatching(path, query, qpos);
        const Path expected_path(&graph, 4, { 0 }, 4);
        ASSERT_EQ(expected_path, extended);
        ASSERT_EQ(qpos, 0ull);
    }
    {
        Graph graph = makeDeletionGraph("AAACC", "ATGCC", "TTAAA");
        const Path path(&graph, 0, { 2 }, 0);
        const string query = "CCT";
        size_t qpos = 2;
        const Path extended = extendPathMatching(path, query, qpos);
        const Path expected_path(&graph, 0, { 2 }, 0);
        ASSERT_EQ(expected_path, extended);
        ASSERT_EQ(qpos, 2ull);
    }
    {
        Graph graph = makeSwapGraph("AAAG", "AGCC", "A", "GTTT");
        const Path path(&graph, 0, { 0 }, 2);
        const string query = "AAAGAG";
        size_t qpos = 0;
        const Path extended = extendPathEndMatching(path, query, qpos);
        const Path expected_path(&graph, 0, { 0 }, 3);
        ASSERT_EQ(expected_path, extended);
        ASSERT_EQ(qpos, 0ull); // extending to right doesn't move qpos
    }
}

TEST(SplittingSequenceByPath, SequenceOfDifferentLength_ExceptionRaised)
{
    Graph graph = makeDeletionGraph("AAAACC", "TTTGG", "ATTT");
    Path path(&graph, 3, { 0, 1 }, 2);
    const string sequence = "AA";
    EXPECT_ANY_THROW(splitSequenceByPath(path, sequence));
}

TEST(SplittingSequenceByPath, SingleNodePath_SequenceSplit)
{
    Graph graph = makeDeletionGraph("AAAACC", "TTTGG", "ATTT");
    Path path(&graph, 1, { 1 }, 3);
    const string sequence = "AAT";
    const vector<string> expected_pieces = { sequence };
    EXPECT_EQ(expected_pieces, splitSequenceByPath(path, sequence));
}

TEST(SplittingSequenceByPath, MultiNodePath_SequenceSplit)
{
    Graph graph = makeDeletionGraph("AAAACC", "TTTGG", "ATTT");
    {
        Path path(&graph, 1, { 0, 1 }, 3);
        const string sequence = "AAAAAGGGG";
        const vector<string> expected_pieces = { "AAAAA", "GGGG" };
        EXPECT_EQ(expected_pieces, splitSequenceByPath(path, sequence));
    }

    {
        Path path(&graph, 3, { 0, 2 }, 1);
        const string sequence = "AAACC";
        const vector<string> expected_pieces = { "AAA", "CC" };
        EXPECT_EQ(expected_pieces, splitSequenceByPath(path, sequence));
    }

    {
        Path path(&graph, 3, { 0, 1, 2 }, 1);
        const string sequence = "AAAGGGGGCC";
        const vector<string> expected_pieces = { "AAA", "GGGGG", "CC" };
        EXPECT_EQ(expected_pieces, splitSequenceByPath(path, sequence));
    }
}

TEST(GraphPathOperations, GraphPathsOverlapDetected)
{
    Graph swap = makeSwapGraph("AAAA", "TTTT", "CCCC", "GGGG");
    {
        const Path p1(&swap, 0, { 0, 1 }, 3);
        const Path p2(&swap, 0, { 1, 3 }, 3);

        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p2, p1));

        const Path expected_merge(&swap, 0, { 0, 1, 3 }, 3);
        ASSERT_EQ(mergePaths(p1, p2), expected_merge);
        ASSERT_EQ(mergePaths(p2, p1), expected_merge);
    }

    {
        const Path p1(&swap, 2, { 0, 1, 3 }, 2);
        const Path p2(&swap, 0, { 1, 3 }, 3);

        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p2, p1));

        const Path expected_merge(&swap, 2, { 0, 1, 3 }, 3);
        ASSERT_EQ(mergePaths(p1, p2), expected_merge);
        ASSERT_EQ(mergePaths(p2, p1), expected_merge);
    }
    {
        const Path p1(&swap, 2, { 0, 2 }, 1);
        const Path p2(&swap, 1, { 2 }, 3);

        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_TRUE(checkPathPrefixSuffixOverlap(p2, p1));

        const Path expected_merge(&swap, 2, { 0, 2 }, 3);
        ASSERT_EQ(mergePaths(p1, p2), expected_merge);
        ASSERT_EQ(mergePaths(p2, p1), expected_merge);
    }
}

TEST(GraphPathOperations, GraphPathsAdjacencyDetected)
{
    Graph graph = makeDoubleSwapGraph("AAAA", "TTTT", "CCCC", "GGGG", "TTTT", "CCCC", "AAAA");

    {
        // p1 ends just before p2 begins
        const Path p1(&graph, 0, { 0, 1 }, 1);
        const Path p2(&graph, 2, { 1, 3 }, 3);

        ASSERT_TRUE(checkIfPathsAdjacent(p1, p2));
        ASSERT_TRUE(checkIfPathsAdjacent(p2, p1));

        const Path expected_merge(&graph, 0, { 0, 1, 3 }, 3);
        ASSERT_EQ(mergePaths(p1, p2), expected_merge);
        ASSERT_EQ(mergePaths(p2, p1), expected_merge);
    }

    {
        // p1 ends too far before p2 begins
        const Path p1(&graph, 0, { 0, 1 }, 0);
        const Path p2(&graph, 2, { 1, 3 }, 3);

        ASSERT_FALSE(checkIfPathsAdjacent(p1, p2));
        ASSERT_FALSE(checkIfPathsAdjacent(p2, p1));
    }
    {
        // p1 ends just before p2 begins
        const Path p1(&graph, 0, { 0, 1 }, 3);
        const Path p2(&graph, 0, { 3 }, 3);

        ASSERT_TRUE(checkIfPathsAdjacent(p1, p2));
        ASSERT_TRUE(checkIfPathsAdjacent(p2, p1));
        const Path expected_merge(&graph, 0, { 0, 1, 3 }, 3);
        ASSERT_EQ(mergePaths(p1, p2), expected_merge);
        ASSERT_EQ(mergePaths(p2, p1), expected_merge);
    }

    {
        // p1 ends too far before p2 begins
        const Path p1(&graph, 0, { 0, 1 }, 2);
        const Path p2(&graph, 0, { 3 }, 3);

        ASSERT_FALSE(checkIfPathsAdjacent(p1, p2));
        ASSERT_FALSE(checkIfPathsAdjacent(p2, p1));
    }

    {
        // p1 ends too far before p2 begins
        const Path p1(&graph, 0, { 0, 1 }, 2);
        const Path p2(&graph, 0, { 4 }, 3);

        ASSERT_FALSE(checkIfPathsAdjacent(p1, p2));
        ASSERT_FALSE(checkIfPathsAdjacent(p2, p1));
    }
}

TEST(GraphPathOperations, GraphPathsNoOverlapDetected)
{
    Graph swap = makeSwapGraph("AAAA", "TTTT", "CCCC", "GGGG");
    {
        // p1 ends before p2 begins
        const Path p1(&swap, 0, { 0, 1 }, 1);
        const Path p2(&swap, 2, { 1, 3 }, 3);

        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p2, p1));
    }

    {
        // no shared nodes
        const Path p1(&swap, 0, { 0 }, 3);
        const Path p2(&swap, 2, { 1, 3 }, 3);

        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p2, p1));
    }

    {
        // incompatible
        const Path p1(&swap, 0, { 0, 1, 3 }, 3);
        const Path p2(&swap, 2, { 0, 2, 3 }, 3);

        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p2, p1));
    }
    {
        // incompatible 2
        const Path p1(&swap, 0, { 0, 1 }, 3);
        const Path p2(&swap, 2, { 2, 3 }, 3);

        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p1, p2));
        ASSERT_FALSE(checkPathPrefixSuffixOverlap(p2, p1));
    }
}

TEST(GraphPathOperations, PathsMergedExhaustively)
{
    Graph swap = makeDoubleSwapGraph("AAAA", "TTTT", "CCCC", "GGGG", "TTTT", "CCCC", "AAAA");

    {
        const Path p0(&swap, 0, { 1, 3 }, 3);
        const Path p1(&swap, 0, { 2, 3 }, 3);
        const Path p2(&swap, 0, { 3, 4 }, 3);
        const Path p3(&swap, 0, { 3, 5 }, 3);

        const std::list<Path> expected_merge{
            Path(&swap, 0, { 1, 3, 4 }, 3),
            Path(&swap, 0, { 2, 3, 5 }, 3),
            Path(&swap, 0, { 2, 3, 4 }, 3),
            Path(&swap, 0, { 1, 3, 5 }, 3),
        };
        std::list<Path> merged{ p0, p1, p2, p3 };
        graphtools::exhaustiveMerge(merged);

#ifdef DEBUG_PATHOPERATIONS_TEST
        for (const auto& p : merged)
        {
            std::cerr << p << std::endl;
        }
#endif
        ASSERT_EQ(merged, expected_merge);
    }
}

TEST(GraphPathOperations, IntersectPaths_NoIntersection)
{
    Graph swap = makeDoubleSwapGraph("AAAA", "TTTT", "CCCC", "GGGG", "TTTT", "CCCC", "AAAA");

    // no shared nodes
    {
        const Path p0(&swap, 0, { 1 }, 3);
        const Path p1(&swap, 0, { 2 }, 3);

        const auto intersection = graphtools::intersectPaths(p0, p1);
        ASSERT_TRUE(intersection.empty());

        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_TRUE(intersection_r.empty());
    }

    // one shared node, but no shared sequence
    {
        const Path p0(&swap, 0, { 1, 3 }, 1);
        const Path p1(&swap, 2, { 3, 4 }, 3);

        const auto intersection = graphtools::intersectPaths(p0, p1);
        ASSERT_TRUE(intersection.empty());

        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_TRUE(intersection_r.empty());
    }
}

TEST(GraphPathOperations, IntersectPaths_SimpleIntersection)
{
    Graph swap = makeDoubleSwapGraph("AAAA", "TTTT", "CCCC", "GGGG", "TTTT", "CCCC", "AAAA");

    // full node is shared
    {
        const Path p0(&swap, 0, { 1, 3, 5 }, 3);
        const Path p1(&swap, 0, { 2, 3, 4 }, 3);

        std::list<Path> expected{
            Path(&swap, 0, { 3 }, 3),

        };

        const auto intersection = graphtools::intersectPaths(p0, p1);
        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_EQ(expected, intersection);
        ASSERT_EQ(expected, intersection_r);
    }

    // partial node is shared
    {
        const Path p0(&swap, 0, { 1, 3 }, 2);
        const Path p1(&swap, 1, { 3, 4 }, 3);

        std::list<Path> expected{
            Path(&swap, 1, { 3 }, 2),

        };

        const auto intersection = graphtools::intersectPaths(p0, p1);
        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_EQ(expected, intersection);
        ASSERT_EQ(expected, intersection_r);
    }
}

TEST(GraphPathOperations, IntersectPaths_ComplexIntersection)
{
    Graph swap = makeDoubleSwapGraph("AAAA", "TTTT", "CCCC", "GGGG", "TTTT", "CCCC", "AAAA");

    // multiple full nodes shared, two resulting paths
    {
        const Path p0(&swap, 0, { 1, 3, 5, 6 }, 3);
        const Path p1(&swap, 0, { 2, 3, 4, 6 }, 3);

        std::list<Path> expected{
            Path(&swap, 0, { 3 }, 3),
            Path(&swap, 0, { 6 }, 3),
        };

        const auto intersection = graphtools::intersectPaths(p0, p1);
        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_EQ(expected, intersection);
        ASSERT_EQ(expected, intersection_r);
    }

    // complex subpath match
    {
        const Path p0(&swap, 0, { 1, 3, 4 }, 2);
        const Path p1(&swap, 0, { 2, 3, 4, 6 }, 3);

        std::list<Path> expected{
            Path(&swap, 0, { 3, 4 }, 2),
        };

        const auto intersection = graphtools::intersectPaths(p0, p1);
        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_EQ(expected, intersection);
        ASSERT_EQ(expected, intersection_r);
    }

    // complex subpath match
    {
        const Path p0(&swap, 0, { 1, 3, 4 }, 2);
        const Path p1(&swap, 2, { 3, 4, 6 }, 3);

        std::list<Path> expected{
            Path(&swap, 2, { 3, 4 }, 2),
        };

        const auto intersection = graphtools::intersectPaths(p0, p1);
        const auto intersection_r = graphtools::intersectPaths(p1, p0);
        ASSERT_EQ(expected, intersection);
        ASSERT_EQ(expected, intersection_r);
    }
}
